<script>
	import Hero from '$lib/components/Hero.svelte';
	import BentoGrid from '$lib/components/BentoGrid.svelte';
	import DesignSystem from '$lib/components/DesignSystem.svelte';
	import Testimonials from '$lib/components/Testimonials.svelte';
	import InteractiveElements from '$lib/components/InteractiveElements.svelte';
	import Contact from '$lib/components/Contact.svelte';
</script>

<Hero />
<BentoGrid />
<DesignSystem />
<Testimonials />
<InteractiveElements />
<Contact />