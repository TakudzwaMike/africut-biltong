<script>
	import { viewport } from '$lib/actions/viewport.js';

	let isVisible = $state(false);
</script>

<section id="bento-grid" class="relative z-10">
	<div class="mx-auto max-w-6xl px-8 py-20 sm:py-24">
		<div
			class="fade-in"
			class:is-visible={isVisible}
			use:viewport={{ threshold: 0.2 }}
			onenterViewport={() => (isVisible = true)}
		>
			<h2 class="text-center text-3xl font-bold tracking-tight text-main sm:text-4xl">
				Component Grid
			</h2>
			<div class="mt-16 grid grid-cols-1 gap-6 md:grid-cols-3">
				<div class="corner-border">
					<h3 class="text-xl font-bold">Quick Stats</h3>
					<p class="mt-2 text-main/70">Users: 10k+<br />Rating: 4.8/5</p>
				</div>
				<div class="corner-border">
					<h3 class="text-xl font-bold">Our Mission</h3>
					<p class="mt-2 text-main/70">
						To deliver excellence and innovation in every project we undertake.
					</p>
				</div>
				<div class="corner-border">
					<h3 class="text-xl font-bold">Special Offer</h3>
					<p class="mt-2 text-main/70">Unlock premium features today with a 20% discount!</p>
				</div>
			</div>
		</div>
	</div>
</section>