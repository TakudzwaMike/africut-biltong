<header class="sticky top-0 z-50 border-b border-main/10 bg-light/80 px-8 backdrop-blur-md">
	<nav class="mx-auto flex max-w-6xl items-center justify-between py-4">
		<a href="/" class="text-xl font-bold">Showcase v4.0</a>
		<ul class="flex items-center gap-6">
			<li>
				<a
					href="#design-system"
					class="font-medium transition hover:text-accent hover:drop-shadow-accent-glow"
					>System</a
				>
			</li>
			<li>
				<a
					href="#testimonials"
					class="font-medium transition hover:text-accent hover:drop-shadow-accent-glow"
					>Voices</a
				>
			</li>
			<li>
				<a
					href="#contact"
					class="font-medium transition hover:text-accent hover:drop-shadow-accent-glow"
					>Contact</a
				>
			</li>
		</ul>
	</nav>
</header>