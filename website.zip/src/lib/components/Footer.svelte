<footer class="relative z-10 border-t border-main/10 bg-light py-8 text-center">
	<p class="text-main/80">© 2025 Component Showcase. All Rights Reserved.</p>
</footer>