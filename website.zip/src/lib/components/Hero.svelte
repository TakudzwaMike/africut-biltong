<script>
	import Modal from './Modal.svelte';
	import { holographic } from '$lib/actions/holographic.js';

	let showModal = $state(false);
</script>

<section id="hero" class="relative z-10 text-center">
	<div class="mx-auto max-w-6xl px-8 py-24 sm:py-32">
		<h1 class="text-4xl font-bold tracking-tight text-main sm:text-6xl">
			Futuristic UI & Motion
		</h1>
		<p class="mx-auto mt-6 max-w-2xl text-lg leading-8 text-main/70">
			An interactive showcase of a modern design system, featuring animated backgrounds and futuristic
			UI elements that respond to user interaction.
		</p>
		<div class="perspective-container mt-10 flex flex-wrap items-center justify-center gap-6">
			<a
				href="#design-system"
				class="holographic-button rounded-md bg-accent px-6 py-3 font-bold text-main shadow-accent-glow"
				use:holographic
			>
				Explore The System
			</a>
			<button
				onclick={() => (showModal = true)}
				class="holographic-button rounded-md bg-main px-6 py-3 font-bold text-light"
				use:holographic
			>
				Open Modal
			</button>
		</div>
	</div>
</section>

<Modal bind:show={showModal}>
	<h3 class="text-xl font-bold text-main">Modal Component</h3>
	<p class="mt-2 text-main/70">
		This is a reusable modal component built with Svelte 5. It uses transitions for smooth
		animations and can be closed by clicking the background, pressing the Escape key, or clicking the
		close button. Any content can be placed inside it using a slot.
	</p>
	<div class="mt-6 flex justify-end">
		<button
			onclick={() => (showModal = false)}
			class="rounded-md bg-accent px-4 py-2 font-bold text-main transition hover:-translate-y-1"
		>
			Got it!
		</button>
	</div>
</Modal>